import { createClient } from "npm:@supabase/supabase-js@2.39.7";
import { google } from "npm:googleapis@133.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

// Initialize Supabase client
const supabaseClient = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
);

// Initialize Google Sheets
const SCOPES = ["https://www.googleapis.com/auth/spreadsheets"];
const SPREADSHEET_ID = Deno.env.get("GOOGLE_SHEET_ID") ?? "";
const SHEET_NAME = "Waitlist";

async function initializeGoogleSheets() {
  const auth = new google.auth.GoogleAuth({
    credentials: JSON.parse(Deno.env.get("GOOGLE_SERVICE_ACCOUNT_KEY") ?? "{}"),
    scopes: SCOPES,
  });

  const sheets = google.sheets({ version: "v4", auth });
  return sheets;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get unsynchronized emails
    const { data: emails, error } = await supabaseClient
      .from("waitlist")
      .select("*")
      .eq("synced_to_sheets", false);

    if (error) throw error;
    if (!emails?.length) {
      return new Response(
        JSON.stringify({ message: "No new emails to sync" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Initialize Google Sheets
    const sheets = await initializeGoogleSheets();

    // Prepare the values to append
    const values = emails.map(record => [
      record.email,
      new Date(record.created_at).toISOString(),
    ]);

    // Append to Google Sheet
    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: `${SHEET_NAME}!A:B`,
      valueInputOption: "USER_ENTERED",
      requestBody: {
        values,
      },
    });

    // Update synced status in Supabase
    const { error: updateError } = await supabaseClient
      .from("waitlist")
      .update({ synced_to_sheets: true })
      .in("id", emails.map(e => e.id));

    if (updateError) throw updateError;

    return new Response(
      JSON.stringify({ 
        message: `Successfully synced ${emails.length} emails`,
        synced: emails.length 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});