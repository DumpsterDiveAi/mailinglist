import React from 'react';
import { DollarSign, TrendingUp, Eye } from 'lucide-react';

const CaseStudy = () => {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
            Success Stories
          </h2>
          
          <div className="bg-indigo-50 rounded-2xl p-6 md:p-10 shadow-lg">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="w-full md:w-1/3 flex justify-center">
                <div className="relative w-48 h-48 rounded-full overflow-hidden bg-indigo-200 border-4 border-white shadow-lg">
                  <img 
                    src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg" 
                    alt="Jamie" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="w-full md:w-2/3">
                <h3 className="text-2xl md:text-3xl font-bold mb-4">
                  Meet Jamie:
                </h3>
                <p className="text-xl text-gray-700 mb-6">
                  He made <span className="font-bold text-indigo-600">$2,300/month</span> from a YouTube channel with just 120 views per video.
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center space-x-3 mb-2">
                      <DollarSign size={20} className="text-green-500" />
                      <h4 className="font-bold">Passive Income</h4>
                    </div>
                    <p className="text-gray-600">From content he had already created</p>
                  </div>
                  
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center space-x-3 mb-2">
                      <TrendingUp size={20} className="text-indigo-500" />
                      <h4 className="font-bold">10x ROI</h4>
                    </div>
                    <p className="text-gray-600">On his initial content creation investment</p>
                  </div>
                  
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center space-x-3 mb-2">
                      <Eye size={20} className="text-purple-500" />
                      <h4 className="font-bold">Low Views</h4>
                    </div>
                    <p className="text-gray-600">Only 120 views per video average</p>
                  </div>
                </div>
                
                <p className="text-gray-700">
                  "I was ready to quit YouTube after my videos weren't getting traction. DumpsterDive showed me I could earn from what I already created, without needing millions of views."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CaseStudy;