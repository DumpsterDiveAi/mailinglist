import React from 'react';
import { Clock, Target, Gift, TrendingUp, Lightbulb, Database } from 'lucide-react';

const Benefits = () => {
  const benefits = [
    {
      icon: <Clock size={28} className="text-indigo-600" />,
      title: "Passive Income Stream",
      description: "Earn money while you sleep from content you've already created."
    },
    {
      icon: <Target size={28} className="text-indigo-600" />,
      title: "No New Content Needed",
      description: "Focus on creating great content, not on optimizing for monetization."
    },
    {
      icon: <Gift size={28} className="text-indigo-600" />,
      title: "Premium Affiliate Partners",
      description: "Access high-paying affiliate programs typically reserved for top creators."
    },
    {
      icon: <TrendingUp size={28} className="text-indigo-600" />,
      title: "Performance Analytics",
      description: "See which content drives the most revenue and optimize accordingly."
    },
    {
      icon: <Lightbulb size={28} className="text-indigo-600" />,
      title: "Content Recommendations",
      description: "Get AI-powered suggestions for new content that could monetize well."
    },
    {
      icon: <Database size={28} className="text-indigo-600" />,
      title: "All Your Platforms",
      description: "Works with YouTube, TikTok, Instagram, blogs, and more."
    }
  ];

  return (
    <section id="benefits" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Built for creators who've tried everything else
            </h2>
            <p className="text-xl text-gray-700 max-w-2xl mx-auto">
              Stop chasing viral hits. Start making money from the content you already have.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 hover:shadow-md transition-shadow duration-300"
              >
                <div className="mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-lg font-bold mb-2">
                  {benefit.title}
                </h3>
                <p className="text-gray-600">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;