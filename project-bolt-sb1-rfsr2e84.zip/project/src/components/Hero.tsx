import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL ?? '',
  import.meta.env.VITE_SUPABASE_ANON_KEY ?? ''
);

const Hero = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');
  
  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email) {
      setError('Please enter your email address');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }

    try {
      const { error: insertError } = await supabase
        .from('waitlist')
        .insert([{ email }]);

      if (insertError) {
        if (insertError.code === '23505') { // Unique constraint violation
          setError('This email is already on the waitlist');
        } else {
          throw insertError;
        }
        return;
      }

      setIsSubmitted(true);
      setEmail('');
      setTimeout(() => setIsSubmitted(false), 3000);

    } catch (err) {
      console.error('Error submitting email:', err);
      setError('Unable to join waitlist. Please try again later.');
    }
  };

  return (
    <section id="hero" className="pt-28 pb-16 md:pt-40 md:pb-24 bg-gradient-to-b from-indigo-50 to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 leading-tight mb-6">
            You Already Made the Content.
            <span className="block text-indigo-600">Let It Pay You.</span>
          </h1>
          
          <p className="text-xl sm:text-2xl text-gray-700 mb-10 max-w-2xl mx-auto leading-relaxed">
            DumpsterDive scans your old YouTube, TikTok, Instagram, or blog content and finds affiliate links to make you money in your sleep.
          </p>
          
          <div id="waitlist" className="max-w-md mx-auto">
            {isSubmitted ? (
              <div className="bg-green-100 text-green-800 p-4 rounded-lg shadow-sm transition-all duration-300 animate-fade-in">
                <p className="font-medium">Thanks for joining the waitlist!</p>
                <p className="text-sm mt-1">We'll notify you when we launch.</p>
              </div>
            ) : error ? (
              <div className="bg-red-100 text-red-800 p-4 rounded-lg shadow-sm transition-all duration-300 animate-fade-in">
                <p className="font-medium">{error}</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-grow px-4 py-3 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent shadow-sm"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  aria-label="Email address"
                />
                <button
                  type="submit"
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full transition-colors duration-200 font-medium shadow-md sm:whitespace-nowrap"
                >
                  Get on the List
                </button>
              </form>
            )}
          </div>
          
          <p className="text-gray-500 text-sm mt-4">
            Join 3,000+ creators already on our waitlist.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Hero;