import React from 'react';
import { Clipboard, SearchCheck, CreditCard } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: <Clipboard size={36} className="text-indigo-600" />,
      title: "Paste Your Handle",
      description: "Connect your social accounts or paste links to your content. It takes less than 2 minutes to set up."
    },
    {
      icon: <SearchCheck size={36} className="text-indigo-600" />,
      title: "We Scan Your Content",
      description: "Our AI identifies products, services, and topics in your content that match high-paying affiliate programs."
    },
    {
      icon: <CreditCard size={36} className="text-indigo-600" />,
      title: "You Get Paid",
      description: "We automatically insert your affiliate links and you earn commissions whenever someone makes a purchase."
    }
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24 bg-gradient-to-b from-white to-indigo-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-6">
            How It Works
          </h2>
          
          <p className="text-xl text-gray-700 text-center mb-16 max-w-2xl mx-auto">
            Simple setup, powerful results. Start monetizing your existing content in minutes.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-md text-center hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex justify-center mb-6">
                  <div className="w-16 h-16 rounded-full bg-indigo-100 flex items-center justify-center">
                    {step.icon}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold mb-3 flex items-center justify-center gap-3">
                  <span className="flex items-center justify-center bg-indigo-600 text-white w-7 h-7 rounded-full text-sm font-bold">
                    {index + 1}
                  </span>
                  {step.title}
                </h3>
                
                <p className="text-gray-600">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <a
              href="#waitlist"
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-full transition-colors font-medium shadow-md"
            >
              Get Started Today
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;