import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqItems = [
    {
      question: "Do I need followers to make money with DumpsterDive?",
      answer: "No! That's the beauty of DumpsterDive. Unlike traditional monetization that requires large audiences, our platform finds affiliate opportunities in your existing content regardless of view count. Even creators with small audiences can generate revenue."
    },
    {
      question: "What platforms do you support?",
      answer: "We currently support YouTube, TikTok, Instagram, Twitter, and most blogging platforms including WordPress, Medium, and Substack. We're constantly adding more platforms based on creator demand."
    },
    {
      question: "Can I use my own affiliate IDs?",
      answer: "Absolutely! You can either use our pre-approved affiliate partnerships (which often have higher commission rates due to our bulk relationships) or connect your existing affiliate accounts. You have complete control over which brands appear in your content."
    },
    {
      question: "How much money can I expect to make?",
      answer: "Results vary based on your content volume, niche, and the products mentioned. Some creators make a few hundred dollars monthly, while others generate thousands. The average creator on our platform earns around $800/month from content that was previously unmonetized."
    },
    {
      question: "Will this affect my existing monetization?",
      answer: "Not at all. DumpsterDive works alongside your current monetization strategies like AdSense, brand deals, or channel memberships. It's an additional revenue stream that complements what you're already doing."
    },
    {
      question: "When will DumpsterDive launch?",
      answer: "We're currently in private beta with select creators. Join our waitlist to be notified when we open up to more creators. We're expanding our user base gradually to ensure the best experience."
    }
  ];

  return (
    <section id="faq" className="py-16 md:py-24 bg-indigo-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
            Frequently Asked Questions
          </h2>
          
          <div className="space-y-4">
            {faqItems.map((item, index) => (
              <div 
                key={index} 
                className="bg-white rounded-lg shadow-sm overflow-hidden"
              >
                <button
                  className="w-full flex items-center justify-between p-6 text-left focus:outline-none"
                  onClick={() => toggleQuestion(index)}
                  aria-expanded={openIndex === index}
                >
                  <span className="text-lg font-medium">{item.question}</span>
                  <span className="ml-6 flex-shrink-0">
                    {openIndex === index ? (
                      <Minus size={20} className="text-indigo-600" />
                    ) : (
                      <Plus size={20} className="text-indigo-600" />
                    )}
                  </span>
                </button>
                
                <div 
                  className={`px-6 overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96 pb-6' : 'max-h-0'
                  }`}
                >
                  <p className="text-gray-600">{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-6">
              Still have questions? We're here to help!
            </p>
            <a
              href="mailto:hello@dumpsterdive.ai"
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-full transition-colors font-medium shadow-md"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;