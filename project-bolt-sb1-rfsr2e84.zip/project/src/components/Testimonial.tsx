import React from 'react';
import { Quote } from 'lucide-react';

const Testimonial = () => {
  return (
    <section id="testimonials" className="py-16 md:py-24 bg-indigo-600 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <Quote size={48} className="text-indigo-300 mx-auto mb-8" />
          
          <blockquote className="text-2xl md:text-3xl font-medium italic mb-8 leading-relaxed">
            I used AutoShorts, grew a library of videos, and got nothing. DumpsterDive showed me I was sitting on gold.
          </blockquote>
          
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full overflow-hidden mb-4 border-2 border-white">
              <img 
                src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg" 
                alt="Sarah J." 
                className="w-full h-full object-cover"
              />
            </div>
            <cite className="not-italic">
              <span className="font-bold block">Sarah J.</span>
              <span className="text-indigo-200">TikTok Creator, 12k followers</span>
            </cite>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;