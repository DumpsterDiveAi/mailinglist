import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import CaseStudy from './components/CaseStudy';
import HowItWorks from './components/HowItWorks';
import Benefits from './components/Benefits';
import Testimonial from './components/Testimonial';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <Header />
      <main>
        <Hero />
        <CaseStudy />
        <HowItWorks />
        <Benefits />
        <Testimonial />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}

export default App;